# Registro y Login de Usuarios con PHP y Mysql
<img src="login-php-mysql.png">

Se explica el proceso a cabalidad para configurar registro de nuevos usuarios, cambio de contraseña y validaciones con usuario existente en el siguiente enlace esta documentado todo, más la puesta a punto en un servidor local:

https://www.configuroweb.com/46-aplicaciones-gratuitas-en-php-python-y-javascript/#registro-y-login-de-usuario

# Contáctame

Si deseas mejor asesoría, desarrollos a medida me puedes contactar en el siguiente enlace:

http://configuroweb.com/WhatsappMessenger
